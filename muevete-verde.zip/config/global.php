<?php
/* Configurar aqui todas las variables globales a utilizar*/
define("APP_NAME", "Promo - Muévete Verde");
define("APP_UNIQUE_KEY", "MueveteVerde2021$");
define("EMPRESA_NAME", "");
define("LOGO_NAME", "./assets/img/logo.png");
define("APP_VERSION", "1.0.1");
define("ROOT_PATH","");   //Root del proyecto

/*URL Body Email*/
define("LOGO_ONLINE","");
define("SITIOWEB_ONLINE","");
define("BODY_EMAIL_TEXT","");
